#include "Vente.h"
#include <iostream>

/************ CONSTRUCTOR *****************/

Vente::Vente(){}

/************* DESTRUCTOR ***************/

Vente::~Vente(){}
