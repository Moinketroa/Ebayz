#include "Mediateur.h"

Mediateur::Mediateur(Compte * monC)
                      : Personne(monC)
{}

Mediateur::~Mediateur(){}
