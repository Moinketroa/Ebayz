#include "Personne.h"

/************ CONSTRUCTOR *****************/

Personne::Personne(Compte * monC)
{
    this->monCompte = monC;
}

/************* DESTRUCTOR ***************/

Personne::~Personne(){}
