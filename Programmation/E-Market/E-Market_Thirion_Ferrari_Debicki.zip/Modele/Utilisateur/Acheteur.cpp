#include "Acheteur.h"

Acheteur::Acheteur(Compte * monC)
                    : Personne(monC)
{}

Acheteur::~Acheteur(){}
